
<div class="sidebar" data-color="danger" data-background-color="danger" data-image= material-dashboard-master/assets/img/sidebar-4.jpg>
    <div class="logo">
        <a  class="simple-text logo-normal">
            Restaurant Management
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li id="menu-dashboard"class="nav-item ">
                <a class="nav-link" href="/dashboard">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li id="menu-accounts"class="nav-item ">
                <a class="nav-link" href="/accounts">
                    <i class="material-icons">person</i>
                    <p>Accounts</p>
                </a>
            </li>
            <li id="menu-menus"class="nav-item ">
                <a class="nav-link" href="/menus">
                    <i class="material-icons">content_paste</i>
                    <p>Menu</p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\Admin\Desktop\cena-resto\resources\views/shared/sidebar.blade.php ENDPATH**/ ?>