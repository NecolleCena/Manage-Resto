@extends('shared.master')

@section('title')
    Dashboard
@endsection

@section('content')

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                    <div class="card-header card-header-success card-header-icon">
                        <div class="card-icon">
                        <i class="material-icons">store</i>
                        </div>
                        <p class="card-category">Store</p>
                        <h3 class="card-title">YoreeKoreanResto</h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">date_range</i> open 24 Hours
                        </div>
                    </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                    <div class="card-header card-header-primary card-header-icon">
                        <div class="card-icon">
                        <i class="fa fa-instagram"></i>
                        </div>
                        <p class="card-category">Instagram</p>
                        <h3 class="card-title">@YoreeKoreanResto</h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">date_range</i> open 24 Hours
                        </div>
                    </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                    <div class="card-header card-header-info card-header-icon">
                        <div class="card-icon">
                        <i class="fa fa-facebook"></i>
                        </div>
                        <p class="card-category">fb page</p>
                        <h3 class="card-title">@YoreeKoreanResto</h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">date_range</i> open 24 Hours
                        </div>
                    </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                    <div class="card-header card-header-tabs card-header-danger">
                        <div class="nav-tabs-navigation">
                        <div class="nav-tabs-wrapper">
                            <span class="nav-tabs-title">Menu:</span>
                            <ul class="nav nav-tabs" data-tabs="tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="#profile" data-toggle="tab">
                                <i class="fas fa-utensils"></i> APPETIZERS
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#messages" data-toggle="tab">
                                <i class="fas fa-utensils"></i> ALA CARTE- MAIN COURSE
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#settings" data-toggle="tab">
                                <i class="fas fa-utensils"></i>   DESSERT
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            </ul>
                        </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                        <div class="tab-pane active" id="profile">
                            <table class="table">
                            <tbody>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="" checked>
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Juk -   Korean porridge made with rice, squid, mussels & vegetable</td>
                                <td class="td-actions text-right">
                                </td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="">
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Gyeranjjim - Light & fluffy steamed egg on a hot stone</td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="">
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Kimchijeon Traditional - Korean pancake made with fermented kimchi </td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="" checked>
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Haemul Pajeon - Traditional Korean pancake with clams, octopus, shrimp and green onion</td>
                                <td class="td-actions text-right"></td>
                                </tr>
                            </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="messages">
                            <table class="table">
                            <tbody>
                                <tr>
                                <td>
                                <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" value="" checked>
                                    <span class="form-check-sign">
                                    <span class="check"></span>
                                    </span>
                                </label>
                                </div>
                                </td>
                                <td>Cheesy Buldak - Spicy fire chicken with mozzarella & cheddar cheese
                                </td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" value="" checked>
                                    <span class="form-check-sign">
                                    <span class="check"></span>
                                    </span>
                                </label>
                                </div>
                                </td>
                                <td>Cheesy Dak Kanjeong - Sweet & spicy fried chicken with mozzarella and cheddar cheese
                                </td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" value="" checked>
                                    <span class="form-check-sign">
                                    <span class="check"></span>
                                    </span>
                                </label>
                                </div>
                                </td>
                                <td>Haemul Sundubu Jjigae: Seafood and silk tofu stew, served with rice
                                </td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="">
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Haejang Guk:  Spicy traditional Korean hangover stew with prime sirloin, congealed ox blood and vegetables, served with rice</td>
                                <td class="td-actions text-right"></td>
                                </tr>
                            </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="settings">
                            <table class="table">
                            <tbody>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="">
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Coconut Sugar Bingsu - Powdery iced snowflakes with coconut sugar and multi-grain powder</td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="" checked>
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Patbingsu - Powdery iced snowflakes with Korean red bean paste
                                </td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="" checked>
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Sikhye - Korean traditional rice drink
                                </td>
                                <td class="td-actions text-right"></td>
                                </tr>
                                <tr>
                                <td>
                                    <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="" checked>
                                        <span class="form-check-sign">
                                        <span class="check"></span>
                                        </span>
                                    </label>
                                    </div>
                                </td>
                                <td>Mango Bingsu - Powdery iced snowflakes with mango</td>
                                <td class="td-actions text-right"> </td>
                                </tr>
                            </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                    <div class="card-header card-header-danger">
                        <h4 class="card-title">Delevery Menu <i class="fa fa-car" aria-hidden="true"></i>
                        <p class="card-category">For Easy Pick Up and Delevery</p>
                    </div>
                    <div class="card-body table-responsive">
                        <table class="table table-hover">
                        <thead class="text-warning">
                            <th>No.</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>prize</th>
                        </thead>
                        <tbody>
                            <tr>
                            <td>1</td>
                            <td>APPETIZERS</td>
                            <td>Kimchijeon</td>
                            <td>Traditional Korean pancake made with fermented kimchi</td>
                            <td>140</td>
                            </tr>
                            <tr>
                            <td>2</td>
                            <td>ALA CARTE SOUP & STEW</td>
                            <td> Galbi Yukgaejang </td>
                            <td> Spicy Korean USDA beef rib stew, served with rice </td>
                            <td>390</td>
                            </tr>
                            <tr>
                            <td>3</td>
                            <td>ALA CARTE- MAIN COURSE</td>
                            <td>Dak Kang Jeong</td>
                            <td> Sweet & spicy boneless fried chicken topped with peanuts </td>
                            <td>400</td>
                            </tr>
                            <tr>
                            <td>4</td>
                            <td>ALA CARTE - RICE & NOODLES</td>
                            <td>Bibim Naengmyeon</td>
                            <td>Long & thin buckwheat noodles served in cold red chili paste topped with julienned cucumber and hard boiled egg</td>
                            <td>290</td>
                            </tr>
                            <td>4</td>
                            <td>DESSERT</td>
                            <td>Mango Bingsu</td>
                            <td>Powdery iced snowflakes with mango</td>
                            <td>150</td>
                            </tr>
                        </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script>

    $('[id^="menu-"]').removeClass('active')
    $('#menu-dashboard').addClass('active')

</script>
@endsection
